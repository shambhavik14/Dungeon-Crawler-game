package dungeon;

/**
 * Types of treasures in the caves.
 */
public enum Treasure {
  RUBY, SAPPHIRES, DIAMONDS
}
